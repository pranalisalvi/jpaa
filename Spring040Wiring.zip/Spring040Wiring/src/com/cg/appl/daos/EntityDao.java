package com.cg.appl.daos;

import com.cg.appl.util.DbUtil;

public class EntityDao {
	private DbUtil dbUtil;
	
	public EntityDao(){
		System.out.println("In Constructor of EntityDao");
	}
	
	public void setDbUtil1(DbUtil dbUtil){
		this.dbUtil= dbUtil;
	}
	
	public void getConnection(){
		dbUtil.getConnection();
	}
	
}
