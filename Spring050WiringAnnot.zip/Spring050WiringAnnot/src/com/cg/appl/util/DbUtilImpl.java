package com.cg.appl.util;

import java.sql.Connection;

public class DbUtilImpl implements DbUtil{
	public DbUtilImpl(){
		System.out.println("In constructor of DbUtil");
	}
	
	public Connection getConnection(){
		System.out.println("In method getConnection DbUtil");
		return null;
	}
}
